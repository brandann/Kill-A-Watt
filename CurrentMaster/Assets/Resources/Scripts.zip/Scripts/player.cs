﻿using UnityEngine;
using System.Collections;

public class player {

    public float score = 0;
    public void plusplus () {
        score++;
    }
}